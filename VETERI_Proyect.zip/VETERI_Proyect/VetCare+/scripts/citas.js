document.addEventListener('DOMContentLoaded', function() {
    const appointmentForm = document.getElementById('appointment-form');
    const appointmentMessage = document.getElementById('appointment-message');

    if (appointmentForm) {
        appointmentForm.addEventListener('submit', function(event) {
            event.preventDefault();
            // Simulación de envío de la cita
            const formData = new FormData(this);
            const appointmentData = {};
            formData.forEach((value, key) => appointmentData[key] = value);
            console.log('Datos de la cita:', appointmentData);

            // Simular respuesta exitosa
            appointmentMessage.textContent = '¡Tu cita ha sido solicitada con éxito! Te contactaremos pronto para confirmarla.';
            appointmentMessage.className = 'appointment-message success';
            appointmentForm.reset(); // Limpiar el formulario

            // En una aplicación real, aquí enviarías los datos a un servidor
        });
    }
});