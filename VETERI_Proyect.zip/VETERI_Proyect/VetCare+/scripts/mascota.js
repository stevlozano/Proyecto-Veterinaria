document.addEventListener('DOMContentLoaded', function() {
    const conoceFechaCheckbox = document.getElementById('conoce-fecha');
    const fechaNacimientoInput = document.getElementById('fecha-nacimiento');

    if (conoceFechaCheckbox && fechaNacimientoInput) {
        conoceFechaCheckbox.addEventListener('change', function() {
            fechaNacimientoInput.disabled = !this.checked;
        });
    }

    const petInfoForm = document.getElementById('pet-info-form');
    if (petInfoForm) {
        petInfoForm.addEventListener('submit', function(event) {
            event.preventDefault();
            // Aquí puedes agregar la lógica para enviar los datos del formulario
            const formData = new FormData(this);
            const petData = {};
            formData.forEach((value, key) => petData[key] = value);
            console.log('Datos de la mascota:', petData);
            alert('Datos de la mascota registrados (simulado)');
            // Puedes redirigir al usuario o realizar otras acciones aquí
        });
    }
});